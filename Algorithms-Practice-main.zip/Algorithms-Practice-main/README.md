# Algorithms-Practice
This repository is dedicated to tracking my data structures and algorithms practice. I use an Anki deck to present DS+algo problems to me at "smart" intervals in order to allow me to get better at implementing certain solutions and to develop my problem solving skills.
<br />
<br />
<img src="https://i.imgur.com/vCoJiJh.png"/>
